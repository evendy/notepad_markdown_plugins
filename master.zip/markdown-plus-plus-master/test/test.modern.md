# Markdown Test (Extra)

\1-2-3 *multiple italic*, **multi bold** and ***multi bold italic***

I have  *a pen **I have an apple**  uuh*  Apple pen.
I have **a pen *I have a pineapple* uuh** Pineapple pen!

I have  *a pen __I have an apple__  uuh*  Apple pen.
I have **a pen _I have a pineapple_ uuh** Pineapple pen!

\* apple \* pen \* <!-- escape test \* t \* t \* t -->

```js
var a = 1 * 1
```
****** <!-- hr -->

## Bullet point test

- normal text

* This should be normal text
* mess up *some thing* (\* suppose \* it's \* normal)
* This should be normal text


